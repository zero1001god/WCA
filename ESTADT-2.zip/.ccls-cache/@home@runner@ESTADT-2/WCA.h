#include <float.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct comp comp;
typedef struct Queue Queue;
#define CAP 100

struct comp {
  char name[50];
  char wcaID[12];  // Example: (2023MAZU05)
  char country[3]; // Example: CO
  float times[5];
};

float get_average_time(float times[5]) {
  float min_time = times[0];
  float max_time = times[0];
  float sum = times[0];

  for (int i = 1; i < 5; i++) {
    sum += times[i];
    if (times[i] < min_time) {
      min_time = times[i];
    }
    if (times[i] > max_time) {
      max_time = times[i];
    }
  }

  return (sum - min_time - max_time) / 3;
}

struct Queue {
  comp competitors[CAP];
  int front, rear, n;
};

void put(Queue *x, comp c) {
  if (x->n == CAP) {
    return;
  }
  x->rear = (x->rear + 1) % CAP;
  x->competitors[x->rear] = c;
  x->n++;
}
void delete (Queue *x) {
  if (empty(x)) {
    return;
  }
  x->front = (x->front + 1) % CAP;
  x->n--;
  return;
}

int empty(Queue *x) { return !x->n; }

void display(Queue *x) {
  int i;
  for (i = 1; i <= x->n; i++) {
    printf("NAME: %s\nWCA ID: %s\nCOUNTRY: %s\nAO5: %.2f\n",
           x->competitors[i].name, x->competitors[i].wcaID,
           x->competitors[i].country,
           get_average_time(x->competitors[i].times));
  }
  return;
}

void displayavg(Queue *x) {
  int i;
  for (i = 1; i <= x->n; i++) {
    printf("%s: %.2f\n", x->competitors[i].name,
           get_average_time(x->competitors[i].times));
  }
  return;
}
void save(Queue *x) {
  FILE *f = fopen("wca1.txt", "a");
  if (f == NULL) {
    printf("here is an error my friend :)\n");
    return;
  }
  for (int i = 1; i <= x->n; i++) {
    fprintf(f, "%s", x->competitors[i].wcaID);
    for (int j = 0; j < 5; j++) {
      fprintf(f, " %.2f", x->competitors[i].times[j]);
    }
    fprintf(f, " = %.2f", get_average_time(x->competitors[i].times));
    fprintf(f, "\n");
  }
  fclose(f);
}
void savecompinfo(Queue *x) {
  FILE *f = fopen("wcainfo.txt", "a");
  if (f == NULL) {
    printf("here is an error my friend :)\n");
    return;
  }
  for (int i = 1; i <= x->n; i++) {
    fprintf(f, "%s\n %s\n %s\n", x->competitors[i].wcaID,
            x->competitors[i].name, x->competitors[i].country);
    for (int j = 0; j < 5; j++) {
      fprintf(f, " %.2f", x->competitors[i].times[j]);
    }
    fprintf(f, " = %.2f", get_average_time(x->competitors[i].times));
    fprintf(f, "\n");
  }
  fclose(f);
}
void results(Queue *x) {
    int i, j;
    for (i = 0; i <= x->n - 1; i++) {
        for (j = 0; j <= x->n - i - 1; j++) {
            if (get_average_time(x->competitors[j].times) > get_average_time(x->competitors[j + 1].times)) {
                comp temp = x->competitors[j];
                x->competitors[j] = x->competitors[j + 1];
                x->competitors[j + 1] = temp;
            }
        }
    }

    printf("Results of the competition:\n");
    for (i = 1; i <= x->n; i++) {
        printf("%d. %s: %.2f\n", i, x->competitors[i].name, get_average_time(x->competitors[i].times));
  }
}

Queue createQueue() {
  Queue q;
  q.front = q.rear = q.n = 0;
  return q;
}