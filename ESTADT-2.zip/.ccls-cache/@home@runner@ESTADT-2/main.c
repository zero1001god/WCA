#include "WCA.h"
#include "credits.h"
#include "scramble.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
  Queue q = createQueue();
  comp new_comp;
  int choice;
  int n;
  int canti;
  int lang;
  do {
    printf("\nWELCOME TO WCA LIVE:\n");
    printf("\nWhere you watch the speedcubing competitions in real time\n");
    printf("1. Add new competitor\n");
    printf("2. Show added competitors\n");
    printf("3. Print result times with their names\n");
    printf("4. Scramble generator? yes, we also had one\n");
    printf("5. save the current competition\n");
    printf("6. save competitors info\n");
    printf("7. Results (just 3x3)\n");
    printf("8. watch the creator an its description :)\n");
    printf("0. Exit\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);
    switch (choice) {
    case 1:
      printf("How many competitors do you want to add? ");
      scanf("%d", &n);
      for (int i = 0; i < n; i++) {
        printf("Enter competitor %d name: ", i + 1);
        scanf("%s", new_comp.name);
        printf("Enter competitor %d WCA ID: ", i + 1);
        scanf("%s", new_comp.wcaID);
        printf("Enter competitor %d country: ", i + 1);
        scanf("%s", new_comp.country);
        printf("Enter competitor %d times: ", i + 1);
        for (int i = 0; i < 5; i++) {
          scanf("%f", &new_comp.times[i]);
        }
        put(&q, new_comp);
      }
      break;

    case 2:
      display(&q);
      break;
    case 3:
      displayavg(&q);
      break;
    case 4:
      printf("Which category do you want?\n");
      printf("1. 3x3\n2. 2x2\n3. Pyraminx ");
      scanf("%d", &canti);
      switch (canti) {
        int c;
      case 1:
        printf("How many scrambles do you want? ");
        scanf("%d", &c);
        generateScramble3x3(20, c);
        printf("\n");
        break;
      case 2:
        printf("How many scrambles do you want? ");
        scanf("%d", &c);
        generateScramble2x2(10, c);
        break;
      case 3:
        printf("How many scrambles do you want? ");
        scanf("%d", &c);
        generateScramblepyra(10, c);
        break;
      default:
        printf("Invalid choice\n");
      }
      break;
    case 5:
      save(&q);
      break;
    case 6:
      savecompinfo(&q);
      break;
    case 7:
      results(&q);
      break;
    case 8:
      printf("Which language do you want?\n");
      printf("1. English\n2. Spanish ");
      scanf(" %d", &lang);
      switch (lang){
        case 1:
          messageenglish();
          break;
        case 2:
          messageSpanish();
          break;
        default:
          printf("Invalid choice\n");
      }
      break;
    default:
      printf("Invalid choice\n");
    }

  } while (choice != 0);
}
