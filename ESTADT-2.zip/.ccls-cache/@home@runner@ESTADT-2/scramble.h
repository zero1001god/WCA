#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define CAP 30
typedef struct Stack Stack;

struct Stack{
  char move[CAP];
  int top;
};

Stack createstack(){
  Stack s;
  s.top=-1;
  return s;
}

void push(Stack *x, char e) {
    if (x->top < CAP - 1) {
        x->move[++x->top] = e;
    } else {
        printf("Require less or more movements!\n");
        exit(1);
    }
}

char pop(Stack *x) {
    if (x->top >= 0) {
        return x->move[x->top--];
    } else {
        printf("Error\n");
        exit(1);
    }
}

void generateScramble3x3(int length, int t) {
  for(int i=0; i<t; i++){
    char moves[] = {'U', 'D', 'L', 'R', 'F', 'B'};
    char modifiers[] = {' ', '\'', '2'};
    char scramble[CAP * 3];
    Stack s = createstack();
    srand((unsigned int)time(NULL)+i);
    char last_move = ' ';
    for (int i = 0; i < length; ++i) {
        char move;
        do {
            move = moves[rand() % 6];
        } while ((move == last_move) || (move == last_move + 1) || (move == last_move - 1));
        last_move = move;
        char mods = modifiers[rand() % 3];
        push(&s, move);
        scramble[i * 3] = move;
        scramble[i * 3 + 1] = mods;
        scramble[i * 3 + 2] = ' ';
    }
    scramble[length * 3 - 1] = '\0';
    printf("Scramble: %s\n", scramble);
  }
}
  

void generateScramble2x2(int length, int t) {
  for(int i=0; i<t; i++){
    char moves[] = {'U', 'R', 'F'};
    char modifiers[] = {' ', '\'', '2'};
    char scramble[CAP * 3];
    Stack s = createstack();
    srand((unsigned int)time(NULL)+i);
    char last_move = ' ';
    for (int i = 0; i < 10; ++i) {
        char move;
        do {
            move = moves[rand() % 3];
        } while ((move == last_move) || (move == last_move + 1) || (move == last_move - 1));
        last_move = move;
        char mods = modifiers[rand() % 3];
        push(&s, move);
        scramble[i * 3] = move;
        scramble[i * 3 + 1] = mods;
        scramble[i * 3 + 2] = ' ';
    }
    scramble[10 * 3 - 1] = '\0';
    printf("Scramble: %s\n", scramble);
  }
}

void generateScramblepyra(int length, int t) {
  for(int i=0; i<t; i++){
    char moves[] = {'U', 'R', 'B', 'L'};
    char modifiers[] = {' ', '\''};
    char scramble[CAP * 2];
    Stack s = createstack();
    srand((unsigned int)time(NULL)+i);
    char last_move = ' ';
    for (int i = 0; i < length; ++i) {
        char move;
        do {
            move = moves[rand() % 4];
        } while ((move == last_move) || (move == last_move + 1) || (move == last_move - 1));
        last_move = move;
        char mods = modifiers[rand() % 2];
        push(&s, move);
        scramble[i * 3] = move;
        scramble[i * 3 + 1] = mods;
        scramble[i * 3 + 2] = ' ';
    }
    scramble[length * 3 - 1] = '\0';
    printf("Scramble: %s\n", scramble);
  }
}
